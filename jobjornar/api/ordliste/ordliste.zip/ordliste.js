    // GLOBAL VARIABLES
    let skjemaSjekkOrd = document.getElementById("sjekkOrd")
    skjemaSjekkOrd.addEventListener("submit", findWord) 
    let inpOrd = document.getElementById("inpOrd")

    
    // Fetch matching words for random pokemon - question
    function findWord(evt) {
        evt.preventDefault()
        ordet = inpOrd.value
        fetch("https://ord.uib.no/api/suggest?q="+ordet+"&n=2&dict=bm,nn")
            .then(checkStatus)
            .then((data) => data.json())
            .then(data => checkWord2(data))
            .catch(error => console.log(error));

    }

    const checkWord2 = function (data) {
        // assign fetched data to variables
        //data
        
        for (i=0; i<data.a.exact.length; i++) {
            console.log(data.a.exact[i])
        }

    }



    // pokeAPI URL with no query 
    const ordAPI = 'https://ord.uib.no/api/';
    //https://ord.uib.no/api/suggest?q=opa&n=2&dict=bm,nn

   
    function checkWord1(evt){
        
        findWord(skjemaSjekkOrd.inpOrd)
    }

 
    function checkStatus(response) {
        if (!response.ok) {
            throw Error(response.statusText);
        }
        return response;
    }

 
       

    // take the fetch results and push all pokemon names to allPokemonsArray
    const createOrdArray = function (data) {
        (data.results).forEach(function (item) {
            allOrdArray.push(item.name);
            console.log(item)
        });
    }


    



